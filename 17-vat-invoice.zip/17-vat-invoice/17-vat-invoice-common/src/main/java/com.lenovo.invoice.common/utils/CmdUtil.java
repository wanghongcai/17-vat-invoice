package com.lenovo.invoice.common.utils;

import org.apache.commons.lang.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by xuweihua on 2016/8/15.
 */
public class CmdUtil {
    private static Logger logger = LoggerFactory.getLogger(CmdUtil.class);
    public static String callCmd(String cmd) throws Exception {
        logger.info("CmdUtil>>SystemUtils.IS_OS_LINUX");
        try {
            // 使用Runtime来执行command，生成Process对象
            Process process = Runtime.getRuntime().exec(cmd);
            int exitCode = process.waitFor();
            // 取得命令结果的输出流
            InputStream is = process.getInputStream();
            // 用一个读输出流类去读
            InputStreamReader isr = new InputStreamReader(is);
            // 用缓冲器读行
            BufferedReader br = new BufferedReader(isr);
            String line = null;
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                System.out.println(line);
                sb.append(line);
            }
            is.close();
            isr.close();
            br.close();
            return sb.toString();
        } catch (java.lang.NullPointerException e) {
            logger.info("NullPointerException " + e.getMessage());
        } catch (java.io.IOException e) {
            logger.info("IOException " + e.getMessage());
        }
        throw new Exception(cmd + "执行出错！");

    }
}
