package com.lenovo.invoice.common.utils;

/**
 * Created by xuweihua on 2016/7/26.
 */
public class InvoiceShopCode {
    //参数错误
    public static final String PARAMETER_ERROR_CODE="10001";
    public static final String SUCCESS="0000";
    public static final String FAIL="9999";
}
