package com.lenovo.invoice.web.controller;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.lenovo.invoice.common.utils.*;;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.StringUtils;

import com.lenovo.m2.hsbuy.address.AreaAddressService;
import com.lenovo.m2.hsbuy.common.smb17.ShopCode;
import com.lenovo.m2.hsbuy.domain.address.PartAddress;
import com.lenovo.m2.hsbuy.domain.address.param.ProvinceParam;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceShop;
import com.lenovo.m2.hsbuy.smb17.InvoiceShopApiService;
import com.lenovo.risk.client.RiskServiceClient;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

/**
 * Created by xuweihua on 2016/6/27.
 */
@Controller
@Scope("prototype")
@RequestMapping("/invoiceShop")
public class InvoiceShopController {
    private Logger logger = LoggerFactory.getLogger(InvoiceShopController.class);
    public static final int PAGE_SIZE=20;

    @Autowired
    private InvoiceShopApiService invoiceShopApiService;


    @Autowired
    private AreaAddressService areaAddressService;

    private RiskServiceClient riskServiceClient = RiskServiceClient.getInstance();


    @RequestMapping("/invoiceShopIndex")
    public String invoiceShopIndex(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        try {
            response.sendRedirect("/invoiceShop/invoiceShopIndexSSO.jhtm");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



    @RequestMapping("/invoiceShopIndexSSO")
    public String invoiceShopIndexSSO(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String userId=getLenovoId(request);
        if(!StringUtils.isEmpty(userId)){
            RemoteResult<List<InvoiceShop>> remoteResult=invoiceShopApiService.queryInvoice(userId);
            //获取20条
            List<InvoiceShop> invoiceShopList=remoteResult.getT();
            List<InvoiceShop> invoices=invoiceShopList.size()>20?invoiceShopList.subList(0,20):invoiceShopList;
            if(CollectionUtils.isNotEmpty(invoices)){
                map.put("shopId",invoices.get(0).getShopId().intValue());
            }
            map.put("invoiceList",sorting(invoices));
        }else {
            map.put("invoiceList", new ArrayList<InvoiceShop>());
        }
        map.put("title","我的发票");
        return "/invoiceShop/invoice";
    }



    @RequestMapping("/invoiceShopIndexPagSSO")
    public String invoiceShopIndexPag(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String userId=getLenovoId(request);
        if(!StringUtils.isEmpty(userId)){
            RemoteResult<List<InvoiceShop>> remoteResult=invoiceShopApiService.queryInvoice(userId);
            //获取20条
            List<InvoiceShop> invoiceShopList=remoteResult.getT();
            List<InvoiceShop>invoices=invoiceShopList.size()>20?invoiceShopList.subList(0,20):invoiceShopList;

            if(CollectionUtils.isNotEmpty(invoices)){
                map.put("shopId",invoices.get(0).getShopId().intValue());
            }

            map.put("invoiceList",sorting(invoices));
        }else {
            map.put("invoiceList", new ArrayList<InvoiceShop>());
        }
        map.put("title","我的发票");

        return "/invoiceShop/invoicePag";
    }
    @RequestMapping("/delInvoiceSSO")
    public String delInvoice(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map,String id){
        String userId=getLenovoId(request);
        if(!StringUtils.isEmpty(userId)) {
            InvoiceShop invoiceShop=new InvoiceShop();
            invoiceShop.setUuid(id);
            invoiceShop.setShopId(ShopCode.smpsShop);
            invoiceShop.setSynType(3);
            invoiceShop.setLenovoID(userId);
            try {
                RemoteResult remoteResult=invoiceShopApiService.modifyePersonalCenter(invoiceShop);
            } catch (Exception e) {
                e.printStackTrace();
                logger.error("delInvoice错误", e);
            }
        }
        map.put("title","我的发票");
        return invoiceShopIndex(request,response,map);
    }


    @RequestMapping("/uploadPag")
    public String UploadPag(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        return "/invoiceShop/upload";
    }

    @RequestMapping("/invoiceShopUploadSSO")
    public String upload(@RequestParam("voucherFile") MultipartFile file,HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        try {
            String userId=getLenovoId(request);
            if(!StringUtils.isEmpty(userId)){
                String [] suffixs=file.getOriginalFilename().split("\\.");
                String url=FileUtils.fileUpload(file.getInputStream(), "."+suffixs[suffixs.length - 1]);
                if(url!=null){
                    map.put("url", url);
                    map.put("msg", "成功！");
                }else {
                    map.put("msg", "失败！");
                }
            }
        } catch (IOException e) {
            logger.error(e.getMessage(),e);
        }
        return "/invoiceShop/uploadMessage";
    }

    @RequestMapping("/invoiceShopUploadxgzpSSO")
    public String uploadxgzp(@RequestParam("voucherFilexgzp") MultipartFile file,HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        try {
            String userId=getLenovoId(request);
            if(!StringUtils.isEmpty(userId)){
                String [] suffixs=file.getOriginalFilename().split("\\.");
                String url=FileUtils.fileUpload(file.getInputStream(), "."+suffixs[suffixs.length - 1]);
                if(url!=null){
                    map.put("url", url);
                    map.put("msg", "成功！");
                }else {
                    map.put("msg", "失败！");
                }
            }
        } catch (IOException e) {
            logger.error(e.getMessage(),e);
        }
        return "/invoiceShop/uploadMessagexgzp";
    }
    @RequestMapping("/testJsonP")
    @ResponseBody
    public String testJsonP(HttpServletRequest request,HttpServletResponse response) {
        String result = "xx";
        String callback = request.getParameter("callback");

        return callback+"('"+result+"')";
    }


    @RequestMapping("/addInvoiceSSO")
    @ResponseBody
    public String addInvoice(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String userId=getLenovoId(request);
        RemoteResult remoteResult=new RemoteResult(false);
        if(!StringUtils.isEmpty(userId)) {
            InvoiceShop invoiceShop =new InvoiceShop();
            try {
                //验证码校验
                /*//存入会话session
                HttpSession session = request.getSession(true);
                String verCode = (String)session.getAttribute("verCode");
                String verifyCode = request.getParameter("verifyCode").toLowerCase();
                logger.info("addInvoice---verCode>>"+ verCode);
                if(!(null!=verCode && !"".equals(verCode) && null!=verifyCode && !"".equals(verifyCode) && verCode.equals(verifyCode))){
                    logger.info("addInvoice---验证码错误"+ JacksonUtil.toJson(verifyCode));
                    return "2";
                }
                logger.info("addInvoice---verifyCode>>"+ verifyCode);*/
                String verifyCode = request.getParameter("verifyCode");
                logger.info("cookie中取出的值:"+getCookieValue(request, "codeid"));
                logger.info("输入的验证码"+verifyCode);
                boolean authCaptcha = riskServiceClient.getMessageCaptchaService()
                        .authCaptcha(getCookieValue(request, "codeid"), verifyCode);
                logger.info("判断的值"+authCaptcha);
                if (!authCaptcha) {
                    logger.info("验证码错误"+authCaptcha);
                    return "2";
                }

                EncapsulationParam.getObjectFromRequest(invoiceShop, request);
                logger.info("addInvoice---参数>>" + JacksonUtil.toJson(invoiceShop));
                invoiceShop.setSynType(1);
                invoiceShop.setLenovoID(userId);
                if(invoiceShop.getPayMan()==null){
                    invoiceShop.setPayMan(invoiceShop.getCustomerName());
                }
                invoiceShop.setCreateBy(userId);
                invoiceShop.setCreateTime(new Date());
                invoiceShop.setShopId(ShopCode.smpsShop);
                if(invoiceShop.getInvoiceType()==1){
                    invoiceShop.setCompanyType(1);
                }
                remoteResult=invoiceShopApiService.modifyePersonalCenter(invoiceShop);
                if(remoteResult.isSuccess()){
                    return "1";
                }else {
                    logger.info("addInvoice---RemoteResult>>"+ JacksonUtil.toJson(remoteResult));
                    return JacksonUtil.toJson(remoteResult);
                }
            }catch (Exception e){
                logger.error("addInvoice错误",e);
                remoteResult.setResultMsg("失败!");
                return JacksonUtil.toJson(remoteResult);
            }
        }
        return "8";
    }


    @RequestMapping("/updateInvoiceSSO")
    @ResponseBody
    public String updateInvoice(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String userId=getLenovoId(request);
        RemoteResult remoteResult=new RemoteResult(false);
        if(!StringUtils.isEmpty(userId)) {
            InvoiceShop invoiceShop =new InvoiceShop();
            try {
                EncapsulationParam.getObjectFromRequest(invoiceShop, request);
                invoiceShop.setSynType(2);
                invoiceShop.setLenovoID(userId);
                invoiceShop.setPayMan(invoiceShop.getCustomerName());
                invoiceShop.setShopId(ShopCode.smpsShop);
                invoiceShop.setUpdateBy(userId);
                invoiceShop.setUpdateTime(new Date());
                if(invoiceShop.getInvoiceType()!=null&&invoiceShop.getInvoiceType()==1){
                    invoiceShop.setApprovalStatus(3);
                }
                remoteResult=invoiceShopApiService.modifyePersonalCenter(invoiceShop);
                if(remoteResult.isSuccess()){
                    return "1";
                }else {
                    logger.info("updateInvoice---RemoteResult>>"+ JacksonUtil.toJson(remoteResult));
                    return JacksonUtil.toJson(remoteResult);
                }
            }catch (Exception e){
                logger.error("updateInvoice错误",e);
                remoteResult.setResultMsg("失败!");
                return JacksonUtil.toJson(remoteResult);
            }
        }
        return "8";
    }



    @RequestMapping("/getProvince")
    @ResponseBody
    public String getProvince(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        Tenant tenant =new Tenant();
        tenant.setShopId(ShopCode.smpsShop);
        RemoteResult<List<PartAddress>>  re = areaAddressService.getProvinceList(tenant);
        StringBuilder provinces=new StringBuilder();
        if(null != re && re.isSuccess()){
            List<PartAddress> provinceList= re.getT();
            for (int i=0;i<provinceList.size();i++){
                if(provinces.length()==0){
                    provinces.append(provinceList.get(i).getName());
                }else {
                    provinces.append(","+provinceList.get(i).getName());
                }
            }
        }
        return provinces.toString();
    }

    @RequestMapping("/getCityList")
    @ResponseBody
    public String getCityList(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map,String province){
        Tenant tenant =new Tenant();
        tenant.setShopId(ShopCode.smpsShop);
        ProvinceParam provinceParam=new ProvinceParam();
        provinceParam.setProvince(province);
        RemoteResult<List<PartAddress>>  re = areaAddressService.getCityList(tenant, provinceParam);
        StringBuilder provinces=new StringBuilder();
        if(null != re && re.isSuccess()){
            List<PartAddress> provinceList= re.getT();
            for (int i=0;i<provinceList.size();i++){
                if(provinces.length()==0){
                    provinces.append(provinceList.get(i).getName());
                }else {
                    provinces.append(","+provinceList.get(i).getName());
                }
            }
        }
        return provinces.toString();
    }

    @RequestMapping("/getRegionList")
    @ResponseBody
    public String getRegionList(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map,String province,String city){
        Tenant tenant =new Tenant();
        tenant.setShopId(ShopCode.smpsShop);
        ProvinceParam provinceParam=new ProvinceParam();
        provinceParam.setProvince(province);
        provinceParam.setCity(city);
        RemoteResult<List<PartAddress>>  re = areaAddressService.getCountyList(tenant,provinceParam);
        StringBuilder provinces=new StringBuilder();
        if(null != re && re.isSuccess()){
            List<PartAddress> provinceList= re.getT();
            for (int i=0;i<provinceList.size();i++){
                if(provinces.length()==0){
                    provinces.append(provinceList.get(i).getName());
                }else {
                    provinces.append(","+provinceList.get(i).getName());
                }
            }
        }
        return provinces.toString();
    }

    @RequestMapping("/getZip")
    @ResponseBody
    public String getZip(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map,String province,String city){
        Tenant tenant =new Tenant();
        tenant.setShopId(ShopCode.smpsShop);
        ProvinceParam provinceParam=new ProvinceParam();
        provinceParam.setProvince(province);
        provinceParam.setCity(city);
        RemoteResult<String>  re = areaAddressService.getZip(tenant,provinceParam);
        String provinces="";
        if(null != re && re.isSuccess()){
            provinces=re.getT();
        }
        return provinces;
    }

    private  List<InvoiceShop> sorting(List<InvoiceShop> invoiceShops){
        List<InvoiceShop> invoiceShopList=new ArrayList<InvoiceShop>();
        for (int i=0;i<invoiceShops.size();i++){
            if(invoiceShops.get(i).getInvoiceType()>0){
                invoiceShopList.add(invoiceShops.get(i));
            }
        }
        for (int i=0;i<invoiceShops.size();i++){
            if(invoiceShops.get(i).getInvoiceType()==0){
                invoiceShopList.add(invoiceShops.get(i));
            }
        }
        return invoiceShopList;
    }

    /**
     *
      从cookie中查找指定的属性值
     **/
    private String getCookieValue(HttpServletRequest request, String cookieName) {
        String value = "";
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                String name = cookie.getName();
                if (cookieName.equals(name)) {
                    value = cookie.getValue();
                    break;
                }
            }
        }
        return value;
    }

    protected String getLenovoId(HttpServletRequest request){
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
        logger.info("The lenovoId from SSO is: " + lenovoId);
        return lenovoId;
//        return "153326";
//        return "209515";
//        return "156208";
//        return "11111111111";
    }

//    @Autowired
//    private InvoiceApiService invoiceApiService;
//
//    @RequestMapping("/ggtest")
//    @ResponseBody
//    public String test(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map,String province,String city){
//        Tenant tenant =new Tenant();
//        tenant.setShopId(9);
//        GetCiParam getCiParam=new GetCiParam();
//        List<FaData> faDatas=new ArrayList<>();
//        FaData faData=new FaData("7ef1d628-5bd3-4651-9530-793678cc02af",0);
//        faDatas.add(faData);
//        getCiParam.setFaDatas(faDatas);
//        getCiParam.setBigDecimal(new BigDecimal(5000));
//        getCiParam.setBu(10);
//        getCiParam.setSalesType(0);
//
//        RemoteResult<ConfigurationInformation> invoiceList=invoiceApiService.getConfigurationInformation(getCiParam,tenant);
//        System.out.println(invoiceList.toString());
//        System.out.println(JacksonUtil.toJson(invoiceList));
//        return JacksonUtil.toJson(invoiceList);
//    }


    public static void main(String[] args) {
        List<InvoiceShop> invoiceShopList= new ArrayList<InvoiceShop>();;
        List<InvoiceShop> invoices=invoiceShopList.size()>20?invoiceShopList.subList(0,20):invoiceShopList;
        System.out.println(invoices.size());
    }
}
