/**
 * Created by mayan3 on 2016/6/30.
 */
public class testEnv {
    public static void main(String[] args) {
        System.out.println(System.getenv("ENV"));
    }
}
